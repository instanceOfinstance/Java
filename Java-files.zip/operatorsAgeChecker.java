public class operatorsAgeChecker {
    public static void main(String[] args) {
        int age = 45;

        // age >= 18
        // age <= 40

        System.out.println(age >= 18 && age <= 40);
    }
}