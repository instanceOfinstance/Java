import java.util.Scanner;

public class Loops {
	static void Loops1 {
		int sum = 0;
		int = 0;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a target: ");


	public static void main(String[] args) {
		int n = 0;
		while(n<100) {
			System.out.println(n);
			n += 1; // n = n+1;
			//n++;
			//n--; // n-=1; n = n-1;
		}
	}
}
