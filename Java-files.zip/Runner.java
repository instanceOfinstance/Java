import java.util.LinkedList;

public class Runner {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();

        list.add(5);
        list.add(3, 12);
    }
}