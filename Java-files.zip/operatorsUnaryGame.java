// A game, score of of the player and the number of turns left

public class operatorsUnaryGame {
    public static void main(String[] args) {
        int score = 0;
        int turns = 10;

        score++;
        turns--;

        System.out.println(score);
        System.out.println(turns);
    }
}