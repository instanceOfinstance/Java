System.out.println(3)

// You can also perfrom math calculations inside the println() method

System.out.println(3 + 3);
