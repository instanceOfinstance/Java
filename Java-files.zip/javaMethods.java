public class javaMethods {
	static void myMethod() {
		System.out.println("Method executed!");
		}

	public static void main(String[] args) {
		myMethod();
	}
}
