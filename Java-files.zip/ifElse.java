public class ifElse {
	static void ifAndElse() {
		int time = 20;
		if (time < 13) {
			System.out.println("Good day.");

		} else {

			System.out.println("Good evening.");
		}

		// Ouputs "Good evening."

		}
	public static void main(String[] args) {
		ifAndElse();

		}
}
